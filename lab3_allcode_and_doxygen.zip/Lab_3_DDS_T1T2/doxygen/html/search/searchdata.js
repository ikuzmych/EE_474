var indexSectionsWithContent =
{
  0: "cdilmnprstx",
  1: "d",
  2: "l",
  3: "ilst",
  4: "cimstx",
  5: "d",
  6: "dnprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

