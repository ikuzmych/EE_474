var searchData=
[
  ['seven_5fseg_5fdigits_0',['seven_seg_digits',['../_lab__3__sync_8ino.html#a059120ac2013439ca98fbdd15f2b9163',1,'Lab_3_sync.ino']]],
  ['sflag_1',['sFlag',['../_lab__3__sync_8ino.html#a4f719e7ed8e72d4df6f927de232f961a',1,'Lab_3_sync.ino']]],
  ['sleepingtime_2',['sleepingTime',['../_lab__3__sync_8ino.html#afbfbcfc01ec3aa50c49d632c79bde532',1,'Lab_3_sync.ino']]],
  ['state_3',['state',['../_lab__3__sync_8ino.html#a522277d4e32881b4be75df30a8546664',1,'Lab_3_sync.ino']]]
];
