var searchData=
[
  ['schedule_5fsync_0',['schedule_sync',['../_lab__3___d_d_s___t5_8ino.html#a83f9d0008aaf4268ec76f3241f9565b9',1,'Lab_3_DDS_T5.ino']]],
  ['scheduler_1',['scheduler',['../_lab__3___d_d_s___t5_8ino.html#a9fa00b0be5d3c4781048861e2506eb63',1,'Lab_3_DDS_T5.ino']]],
  ['setup_2',['setup',['../_lab__3___d_d_s___t5_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Lab_3_DDS_T5.ino']]],
  ['sleep_5f474_3',['sleep_474',['../_lab__3___d_d_s___t5_8ino.html#adb2bea98b6ff09ca57694403daa07f02',1,'Lab_3_DDS_T5.ino']]],
  ['start_5ffunction_4',['start_function',['../_lab__3___d_d_s___t5_8ino.html#a531a04f40cf092607dba62ef0fe0f3ff',1,'Lab_3_DDS_T5.ino']]]
];
