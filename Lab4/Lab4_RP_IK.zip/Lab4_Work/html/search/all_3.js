var searchData=
[
  ['lab4_5fwork_2eino_0',['Lab4_Work.ino',['../_lab4___work_8ino.html',1,'']]],
  ['loop_1',['loop',['../_lab4___work_8ino.html#afe461d27b9c48d5921c00d521181f12f',1,'Lab4_Work.ino']]]
];
