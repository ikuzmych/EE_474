var searchData=
[
  ['task1_0',['task1',['../_lab__3__sync__alltasks_8ino.html#ab55078d807df0a75af8a2fa8eefdcc41',1,'Lab_3_sync_alltasks.ino']]],
  ['task2_1',['task2',['../_lab__3__sync__alltasks_8ino.html#a03bef279de31d91a79b14f31c4530dfc',1,'Lab_3_sync_alltasks.ino']]],
  ['task3_2',['task3',['../_lab__3__sync__alltasks_8ino.html#a800ed86ba3f4e578d81215c99b2ad914',1,'Lab_3_sync_alltasks.ino']]],
  ['task_5findex_3',['task_index',['../_lab__3__sync__alltasks_8ino.html#ae2db4f5bc477001abcb8987f30e6b22c',1,'Lab_3_sync_alltasks.ino']]],
  ['taskpointers_4',['taskPointers',['../_lab__3__sync__alltasks_8ino.html#abc5981e1cf4e13e12030282eb053bd2e',1,'Lab_3_sync_alltasks.ino']]],
  ['timer_5',['timer',['../_lab__3__sync__alltasks_8ino.html#a61d9ef65d75b66821896182b133b31de',1,'Lab_3_sync_alltasks.ino']]]
];
