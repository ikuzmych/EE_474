var searchData=
[
  ['curr_0',['curr',['../_lab__3__sync_8ino.html#a96010e8f175b18e5988b95a0cf09faa1',1,'Lab_3_sync.ino']]]
];
