var searchData=
[
  ['task1_0',['task1',['../lab3_8ino.html#aa4b9e8a693c962073b3a90075f610bde',1,'lab3.ino']]],
  ['task2_1',['task2',['../lab3_8ino.html#ae63d49f06a2173ae67a8f1ef97b4b2f0',1,'lab3.ino']]],
  ['task3_2',['task3',['../lab3_8ino.html#a2052eb498fb74bec084a80c8829e6912',1,'lab3.ino']]],
  ['timer_3',['timer',['../lab3_8ino.html#a61d9ef65d75b66821896182b133b31de',1,'lab3.ino']]]
];
