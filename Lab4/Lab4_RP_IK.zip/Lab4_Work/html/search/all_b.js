var searchData=
[
  ['xqueue1_0',['xQueue1',['../_lab4___work_8ino.html#aaae7f0f81206454087a62e4c8fa62dec',1,'Lab4_Work.ino']]],
  ['xqueue2_1',['xQueue2',['../_lab4___work_8ino.html#a6bd84b5caea4b77e52577fda94b1940d',1,'Lab4_Work.ino']]]
];
