var searchData=
[
  ['task2_0',['task2',['../_lab__3___d_d_s___t4_8ino.html#a03bef279de31d91a79b14f31c4530dfc',1,'Lab_3_DDS_T4.ino']]],
  ['task3_1',['task3',['../_lab__3___d_d_s___t4_8ino.html#a800ed86ba3f4e578d81215c99b2ad914',1,'Lab_3_DDS_T4.ino']]]
];
