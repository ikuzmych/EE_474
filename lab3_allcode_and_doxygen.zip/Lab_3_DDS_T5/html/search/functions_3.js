var searchData=
[
  ['task1_0',['task1',['../_lab__3___d_d_s___t5_8ino.html#ab55078d807df0a75af8a2fa8eefdcc41',1,'Lab_3_DDS_T5.ino']]],
  ['task2_1',['task2',['../_lab__3___d_d_s___t5_8ino.html#a03bef279de31d91a79b14f31c4530dfc',1,'Lab_3_DDS_T5.ino']]],
  ['task3_2',['task3',['../_lab__3___d_d_s___t5_8ino.html#a800ed86ba3f4e578d81215c99b2ad914',1,'Lab_3_DDS_T5.ino']]],
  ['task_5fself_5fquit_3',['task_self_quit',['../_lab__3___d_d_s___t5_8ino.html#acc5cbf1054ebf6f9cb6e2ea3ee2ce948',1,'Lab_3_DDS_T5.ino']]],
  ['task_5fstart_4',['task_start',['../_lab__3___d_d_s___t5_8ino.html#a890a80062601ed4c24fca6bc9f1e1197',1,'Lab_3_DDS_T5.ino']]]
];
