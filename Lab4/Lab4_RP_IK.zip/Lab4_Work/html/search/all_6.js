var searchData=
[
  ['p_0',['p',['../_lab4___work_8ino.html#a4358f3fd272a7fe3ef24c9e959bab91e',1,'Lab4_Work.ino']]]
];
