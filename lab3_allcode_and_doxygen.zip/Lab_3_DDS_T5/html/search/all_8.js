var searchData=
[
  ['schedule_5fsync_0',['schedule_sync',['../_lab__3___d_d_s___t5_8ino.html#a83f9d0008aaf4268ec76f3241f9565b9',1,'Lab_3_DDS_T5.ino']]],
  ['scheduler_1',['scheduler',['../_lab__3___d_d_s___t5_8ino.html#a9fa00b0be5d3c4781048861e2506eb63',1,'Lab_3_DDS_T5.ino']]],
  ['setup_2',['setup',['../_lab__3___d_d_s___t5_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Lab_3_DDS_T5.ino']]],
  ['seven_5fseg_5fdigits_3',['seven_seg_digits',['../_lab__3___d_d_s___t5_8ino.html#a059120ac2013439ca98fbdd15f2b9163',1,'Lab_3_DDS_T5.ino']]],
  ['sflag_4',['sFlag',['../_lab__3___d_d_s___t5_8ino.html#a4f719e7ed8e72d4df6f927de232f961a',1,'Lab_3_DDS_T5.ino']]],
  ['sleep_5f474_5',['sleep_474',['../_lab__3___d_d_s___t5_8ino.html#adb2bea98b6ff09ca57694403daa07f02',1,'Lab_3_DDS_T5.ino']]],
  ['sleeping_6',['SLEEPING',['../_lab__3___d_d_s___t5_8ino.html#a4b221cbe3abc6fdb3f34a11d55540f4f',1,'Lab_3_DDS_T5.ino']]],
  ['sleeptime_7',['sleepTime',['../struct_d_d_s.html#a1ce7f51b315b38dd1db21e237585888f',1,'DDS']]],
  ['start_5ffunction_8',['start_function',['../_lab__3___d_d_s___t5_8ino.html#a531a04f40cf092607dba62ef0fe0f3ff',1,'Lab_3_DDS_T5.ino']]],
  ['state_9',['state',['../struct_d_d_s.html#a71262dfbf1e2fda127157f20877c1463',1,'DDS']]]
];
