var searchData=
[
  ['dead_0',['DEAD',['../_lab__3___d_d_s___t1_t2_8ino.html#a3c8793c7acb4598d2ebcd8288f29ee69',1,'Lab_3_DDS_T1T2.ino']]],
  ['delay_5ftimeout_5fvalue_1',['DELAY_TIMEOUT_VALUE',['../_lab__3___d_d_s___t1_t2_8ino.html#afe8489beb4ce353f467cfe21a41db85c',1,'Lab_3_DDS_T1T2.ino']]],
  ['done_2',['DONE',['../_lab__3___d_d_s___t1_t2_8ino.html#abe6b865c045f3e7c6892ef4f15ff5779',1,'Lab_3_DDS_T1T2.ino']]]
];
