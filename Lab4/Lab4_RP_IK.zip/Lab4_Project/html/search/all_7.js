var searchData=
[
  ['readdata_0',['readData',['../_lab4___project_8ino.html#a83f68abe7b27de5749262c57aeb18904',1,'Lab4_Project.ino']]]
];
