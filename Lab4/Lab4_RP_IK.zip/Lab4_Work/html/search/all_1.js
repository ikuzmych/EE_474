var searchData=
[
  ['curr_0',['curr',['../_lab4___work_8ino.html#a901bfd7d1561197d61df17d5ac5cb01f',1,'Lab4_Work.ino']]]
];
