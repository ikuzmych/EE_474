var searchData=
[
  ['ready_0',['READY',['../_lab__3___d_d_s___t1_t2_8ino.html#ad1235d5ce36f7267285e82dccd428aa6',1,'Lab_3_DDS_T1T2.ino']]],
  ['running_1',['RUNNING',['../_lab__3___d_d_s___t1_t2_8ino.html#a6fb7181d994ee98e735494be55809708',1,'Lab_3_DDS_T1T2.ino']]]
];
