var searchData=
[
  ['task_5findex_0',['task_index',['../_lab__3___d_d_s___t1_t2_8ino.html#ae2db4f5bc477001abcb8987f30e6b22c',1,'Lab_3_DDS_T1T2.ino']]],
  ['taskname_1',['taskName',['../struct_d_d_s.html#afc12250a8e17126a863a3e96909b04c5',1,'DDS']]],
  ['tasks_2',['TASKS',['../_lab__3___d_d_s___t1_t2_8ino.html#a1c788ddd6cd82f98a6e11330f514eebe',1,'Lab_3_DDS_T1T2.ino']]],
  ['timer_3',['timer',['../_lab__3___d_d_s___t1_t2_8ino.html#a61d9ef65d75b66821896182b133b31de',1,'Lab_3_DDS_T1T2.ino']]],
  ['timesstarted_4',['timesStarted',['../struct_d_d_s.html#a207d690a86dcac24f6a0dcee68f48ecd',1,'DDS']]]
];
