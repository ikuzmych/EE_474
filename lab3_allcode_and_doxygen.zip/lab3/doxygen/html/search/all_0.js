var searchData=
[
  ['counter_0',['counter',['../lab3_8ino.html#a2c605870a4e5975004e2e04a9a033d35',1,'lab3.ino']]],
  ['curr_1',['curr',['../lab3_8ino.html#a96010e8f175b18e5988b95a0cf09faa1',1,'lab3.ino']]]
];
