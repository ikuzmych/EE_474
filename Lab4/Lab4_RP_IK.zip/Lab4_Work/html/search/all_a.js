var searchData=
[
  ['vimag_0',['vImag',['../_lab4___work_8ino.html#a935cafe90680ca32b8ac2dfadf72d84b',1,'Lab4_Work.ino']]],
  ['vreal_1',['vReal',['../_lab4___work_8ino.html#ab607e4e8fccba4d33892294e9382e5bb',1,'Lab4_Work.ino']]]
];
