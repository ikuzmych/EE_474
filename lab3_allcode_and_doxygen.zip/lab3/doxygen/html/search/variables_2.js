var searchData=
[
  ['seven_5fseg_5fdigits_0',['seven_seg_digits',['../lab3_8ino.html#a059120ac2013439ca98fbdd15f2b9163',1,'lab3.ino']]],
  ['sleep_1',['sleep',['../lab3_8ino.html#a3878b47b9f5c775bf83b7c541a1ab796',1,'lab3.ino']]]
];
