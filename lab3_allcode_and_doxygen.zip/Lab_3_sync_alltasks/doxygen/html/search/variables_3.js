var searchData=
[
  ['task_5findex_0',['task_index',['../_lab__3__sync__alltasks_8ino.html#ae2db4f5bc477001abcb8987f30e6b22c',1,'Lab_3_sync_alltasks.ino']]],
  ['taskpointers_1',['taskPointers',['../_lab__3__sync__alltasks_8ino.html#abc5981e1cf4e13e12030282eb053bd2e',1,'Lab_3_sync_alltasks.ino']]],
  ['timer_2',['timer',['../_lab__3__sync__alltasks_8ino.html#a61d9ef65d75b66821896182b133b31de',1,'Lab_3_sync_alltasks.ino']]]
];
