var searchData=
[
  ['pending_0',['PENDING',['../_lab__3__sync__alltasks_8ino.html#a9960d0d5ae92fc92c70bbb84c2a5c0cc',1,'Lab_3_sync_alltasks.ino']]]
];
