var searchData=
[
  ['n_5ftasks_0',['N_TASKS',['../_lab__3__sync_8ino.html#ab1a5b1011baa69070c3fc1b46b8b21d1',1,'Lab_3_sync.ino']]],
  ['note_5f1_1',['NOTE_1',['../_lab__3__sync_8ino.html#abfcf833ab1560c284e33123b2fed08ea',1,'Lab_3_sync.ino']]],
  ['note_5f2_2',['NOTE_2',['../_lab__3__sync_8ino.html#a6b725bb0da609a027f0cdad68c103242',1,'Lab_3_sync.ino']]],
  ['note_5f3_3',['NOTE_3',['../_lab__3__sync_8ino.html#a60413e7436433c4e373a59d3c4ce00d3',1,'Lab_3_sync.ino']]],
  ['note_5f4_4',['NOTE_4',['../_lab__3__sync_8ino.html#a2edcc96e70acbdd095d3f8cb79a60837',1,'Lab_3_sync.ino']]],
  ['note_5f5_5',['NOTE_5',['../_lab__3__sync_8ino.html#a5512b7437c976f78f24ea0f5101f2461',1,'Lab_3_sync.ino']]],
  ['note_5frest_6',['NOTE_rest',['../_lab__3__sync_8ino.html#a3615b379fd94367334710f66596458c7',1,'Lab_3_sync.ino']]]
];
