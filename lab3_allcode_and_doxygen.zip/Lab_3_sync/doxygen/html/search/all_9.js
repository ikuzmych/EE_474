var searchData=
[
  ['task1_0',['task1',['../_lab__3__sync_8ino.html#ab55078d807df0a75af8a2fa8eefdcc41',1,'Lab_3_sync.ino']]],
  ['task2_1',['task2',['../_lab__3__sync_8ino.html#a03bef279de31d91a79b14f31c4530dfc',1,'Lab_3_sync.ino']]],
  ['task_5findex_2',['task_index',['../_lab__3__sync_8ino.html#ae2db4f5bc477001abcb8987f30e6b22c',1,'Lab_3_sync.ino']]],
  ['taskpointers_3',['taskPointers',['../_lab__3__sync_8ino.html#abc5981e1cf4e13e12030282eb053bd2e',1,'Lab_3_sync.ino']]],
  ['timer_4',['timer',['../_lab__3__sync_8ino.html#a61d9ef65d75b66821896182b133b31de',1,'Lab_3_sync.ino']]]
];
