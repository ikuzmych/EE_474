var searchData=
[
  ['delay_5ftimeout_5fvalue_0',['DELAY_TIMEOUT_VALUE',['../_lab__3__sync_8ino.html#afe8489beb4ce353f467cfe21a41db85c',1,'Lab_3_sync.ino']]],
  ['done_1',['DONE',['../_lab__3__sync_8ino.html#abe6b865c045f3e7c6892ef4f15ff5779',1,'Lab_3_sync.ino']]]
];
