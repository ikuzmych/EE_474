var searchData=
[
  ['setup_0',['setup',['../lab3_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'lab3.ino']]],
  ['seven_5fseg_5fdigits_1',['seven_seg_digits',['../lab3_8ino.html#a059120ac2013439ca98fbdd15f2b9163',1,'lab3.ino']]],
  ['sleep_2',['sleep',['../lab3_8ino.html#a3878b47b9f5c775bf83b7c541a1ab796',1,'lab3.ino']]]
];
