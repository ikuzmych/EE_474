var searchData=
[
  ['setup_0',['setup',['../_lab4___project_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Lab4_Project.ino']]],
  ['six_5ffeet_1',['SIX_FEET',['../_lab4___project_8ino.html#a7026cba374346a43dda2b4b3a83aef6a',1,'Lab4_Project.ino']]]
];
