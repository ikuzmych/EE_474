var searchData=
[
  ['amplitude_0',['amplitude',['../_lab4___work_8ino.html#ad07f93f796ba0af60659c528f7611d4a',1,'Lab4_Work.ino']]]
];
