var searchData=
[
  ['task1_0',['task1',['../_lab__3___d_d_s___t5_8ino.html#ab55078d807df0a75af8a2fa8eefdcc41',1,'Lab_3_DDS_T5.ino']]],
  ['task2_1',['task2',['../_lab__3___d_d_s___t5_8ino.html#a03bef279de31d91a79b14f31c4530dfc',1,'Lab_3_DDS_T5.ino']]],
  ['task3_2',['task3',['../_lab__3___d_d_s___t5_8ino.html#a800ed86ba3f4e578d81215c99b2ad914',1,'Lab_3_DDS_T5.ino']]],
  ['task_5findex_3',['task_index',['../_lab__3___d_d_s___t5_8ino.html#ae2db4f5bc477001abcb8987f30e6b22c',1,'Lab_3_DDS_T5.ino']]],
  ['task_5fself_5fquit_4',['task_self_quit',['../_lab__3___d_d_s___t5_8ino.html#acc5cbf1054ebf6f9cb6e2ea3ee2ce948',1,'Lab_3_DDS_T5.ino']]],
  ['task_5fstart_5',['task_start',['../_lab__3___d_d_s___t5_8ino.html#a890a80062601ed4c24fca6bc9f1e1197',1,'Lab_3_DDS_T5.ino']]],
  ['taskname_6',['taskName',['../struct_d_d_s.html#afc12250a8e17126a863a3e96909b04c5',1,'DDS']]],
  ['tasks_7',['TASKS',['../_lab__3___d_d_s___t5_8ino.html#a1c788ddd6cd82f98a6e11330f514eebe',1,'Lab_3_DDS_T5.ino']]],
  ['timer_8',['timer',['../_lab__3___d_d_s___t5_8ino.html#a61d9ef65d75b66821896182b133b31de',1,'Lab_3_DDS_T5.ino']]],
  ['timesstarted_9',['timesStarted',['../struct_d_d_s.html#a207d690a86dcac24f6a0dcee68f48ecd',1,'DDS']]]
];
