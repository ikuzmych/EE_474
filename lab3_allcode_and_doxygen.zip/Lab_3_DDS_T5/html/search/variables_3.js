var searchData=
[
  ['seven_5fseg_5fdigits_0',['seven_seg_digits',['../_lab__3___d_d_s___t5_8ino.html#a059120ac2013439ca98fbdd15f2b9163',1,'Lab_3_DDS_T5.ino']]],
  ['sflag_1',['sFlag',['../_lab__3___d_d_s___t5_8ino.html#a4f719e7ed8e72d4df6f927de232f961a',1,'Lab_3_DDS_T5.ino']]],
  ['sleeptime_2',['sleepTime',['../struct_d_d_s.html#a1ce7f51b315b38dd1db21e237585888f',1,'DDS']]],
  ['state_3',['state',['../struct_d_d_s.html#a71262dfbf1e2fda127157f20877c1463',1,'DDS']]]
];
