var searchData=
[
  ['freq1_0',['freq1',['../_lab__3___d_d_s___t4_8ino.html#a34b1ed5e1f0aad26211212c7925151d6',1,'Lab_3_DDS_T4.ino']]],
  ['freq2_1',['freq2',['../_lab__3___d_d_s___t4_8ino.html#a379c81f1d0a295876e798e6723636da6',1,'Lab_3_DDS_T4.ino']]],
  ['freq3_2',['freq3',['../_lab__3___d_d_s___t4_8ino.html#a3dbc89e4a6e3d47dcfe952219e3904f9',1,'Lab_3_DDS_T4.ino']]],
  ['freq4_3',['freq4',['../_lab__3___d_d_s___t4_8ino.html#abfc02758b94019110f45e945611bae61',1,'Lab_3_DDS_T4.ino']]],
  ['freq5_4',['freq5',['../_lab__3___d_d_s___t4_8ino.html#a5a7342a63159d3ac91a53746be2bd5bd',1,'Lab_3_DDS_T4.ino']]],
  ['freqr_5',['freqR',['../_lab__3___d_d_s___t4_8ino.html#ac5beaf196ca3606d0e7a8dcf3f3397a1',1,'Lab_3_DDS_T4.ino']]],
  ['frequencies_6',['frequencies',['../_lab__3___d_d_s___t4_8ino.html#a7849fa57ad6cdd15adac0f517f394998',1,'Lab_3_DDS_T4.ino']]]
];
