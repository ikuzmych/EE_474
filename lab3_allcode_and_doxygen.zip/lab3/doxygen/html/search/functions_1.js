var searchData=
[
  ['setup_0',['setup',['../lab3_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'lab3.ino']]]
];
