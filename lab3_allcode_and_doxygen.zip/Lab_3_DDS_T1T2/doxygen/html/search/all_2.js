var searchData=
[
  ['id_0',['id',['../struct_d_d_s.html#aba887845e45ff76e3e21b764d409d264',1,'DDS']]],
  ['isr_1',['ISR',['../_lab__3___d_d_s___t1_t2_8ino.html#a86953738188622410b88938da2bf8a63',1,'Lab_3_DDS_T1T2.ino']]]
];
