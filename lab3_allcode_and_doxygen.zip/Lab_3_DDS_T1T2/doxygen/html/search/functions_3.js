var searchData=
[
  ['task1_0',['task1',['../_lab__3___d_d_s___t1_t2_8ino.html#ab55078d807df0a75af8a2fa8eefdcc41',1,'Lab_3_DDS_T1T2.ino']]],
  ['task2_1',['task2',['../_lab__3___d_d_s___t1_t2_8ino.html#a03bef279de31d91a79b14f31c4530dfc',1,'Lab_3_DDS_T1T2.ino']]]
];
