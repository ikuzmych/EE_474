var searchData=
[
  ['setup_0',['setup',['../_lab4___work_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Lab4_Work.ino']]]
];
