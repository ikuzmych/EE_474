var searchData=
[
  ['sleeping_0',['SLEEPING',['../_lab__3___d_d_s___t1_t2_8ino.html#a4b221cbe3abc6fdb3f34a11d55540f4f',1,'Lab_3_DDS_T1T2.ino']]]
];
