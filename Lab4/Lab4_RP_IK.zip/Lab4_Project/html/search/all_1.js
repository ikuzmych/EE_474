var searchData=
[
  ['distance_0',['distance',['../_lab4___project_8ino.html#afb9412686cd344ad61757c1c19ba8a87',1,'Lab4_Project.ino']]],
  ['duration_1',['duration',['../_lab4___project_8ino.html#a49411c0db3bc12e9d548e069021b0645',1,'Lab4_Project.ino']]]
];
